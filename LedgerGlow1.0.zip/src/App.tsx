import { useState, useEffect } from 'react';
import { Dashboard } from '@/pages/Dashboard';
import { Settings } from '@/pages/Settings';
import { AllTransactions } from '@/pages/AllTransactions';
import { Auth } from '@/pages/Auth';
import { Toaster } from '@/components/ui/toaster';
import { useAuthStore, initializeAuth } from '@/stores/authStore';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

function App() {
  const [currentPage, setCurrentPage] = useState<'dashboard' | 'settings' | 'transactions'>('dashboard');
  const { user, loading } = useAuthStore();
  const { toast } = useToast();
  
  useEffect(() => {
    // Don't initialize auth if there's a password recovery token in the URL
    const hashParams = new URLSearchParams(window.location.hash.substring(1));
    const isRecovery = hashParams.get('type') === 'recovery';
    
    if (isRecovery) {
      console.log('Recovery mode detected - skipping auth initialization');
      // Set loading to false to show the Auth page immediately
      useAuthStore.getState().setLoading(false);
      return;
    }
    
    const cleanup = initializeAuth();
    return cleanup;
  }, []);
  
  // Load guest data on mount if user is guest
  useEffect(() => {
    if (user?.isGuest) {
      import('@/stores/financeStore').then(({ useFinanceStore }) => {
        useFinanceStore.getState().loadUserData('guest');
      });
    }
  }, [user?.isGuest]);
  
  const handleViewAllTransactions = () => {
    console.log('App: handleViewAllTransactions called, setting page to transactions');
    setCurrentPage('transactions');
  };
  
  const handleLogout = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    } else {
      toast({
        title: 'Logged out',
        description: 'See you soon!',
      });
    }
  };
  
  // Show loading spinner
  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block h-12 w-12 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent mb-4"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }
  
  // Show auth page if not logged in
  if (!user) {
    return (
      <>
        <Auth />
        <Toaster />
      </>
    );
  }
  
  return (
    <>
      {currentPage === 'dashboard' && (
        <Dashboard 
          onOpenSettings={() => setCurrentPage('settings')}
          onViewAllTransactions={handleViewAllTransactions}
        />
      )}
      {currentPage === 'settings' && (
        <Settings onBack={() => setCurrentPage('dashboard')} onLogout={handleLogout} />
      )}
      {currentPage === 'transactions' && (
        <AllTransactions onBack={() => setCurrentPage('dashboard')} />
      )}
      <Toaster />
    </>
  );
}

export default App;
