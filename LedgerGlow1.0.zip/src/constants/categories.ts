import { Category } from '@/types';

export const EXPENSE_CATEGORIES: Category[] = [
  { id: 'rent', name: 'Rent', emoji: '🏠', color: 'hsl(15, 100%, 60%)' },
  { id: 'transportation', name: 'Transportation', emoji: '🚗', color: 'hsl(210, 100%, 60%)' },
  { id: 'utilities', name: 'Tuition', emoji: '📚', color: 'hsl(45, 100%, 55%)' },
  { id: 'food', name: 'Food', emoji: '🍔', color: 'hsl(25, 100%, 60%)' },
  { id: 'entertainment', name: 'Entertainment', emoji: '🎬', color: 'hsl(330, 100%, 60%)' },
  { id: 'subscriptions', name: 'Subscriptions', emoji: '📺', color: 'hsl(280, 100%, 65%)' },
  { id: 'shopping', name: 'Shopping', emoji: '🛍️', color: 'hsl(300, 100%, 60%)' },
  { id: 'health', name: 'Health', emoji: '💊', color: 'hsl(0, 100%, 65%)' },
  { id: 'other-expense', name: 'Other Expense', emoji: '📦', color: 'hsl(200, 20%, 50%)' },
];

export const INCOME_CATEGORIES: Category[] = [
  { id: 'salary', name: 'Salary', emoji: '💼', color: 'hsl(142, 76%, 45%)' },
  { id: 'freelance', name: 'Freelance', emoji: '💻', color: 'hsl(160, 70%, 50%)' },
  { id: 'other-income', name: 'Other Income', emoji: '🗂️', color: 'hsl(180, 70%, 50%)' },
  { id: 'bonus', name: 'Bonus', emoji: '💰', color: 'hsl(140, 60%, 50%)' },
];

export const CURRENCIES = [
  { code: 'USD', symbol: '$', name: 'US Dollar' },
  { code: 'EUR', symbol: '€', name: 'Euro' },
  { code: 'GBP', symbol: '£', name: 'British Pound' },
  { code: 'CAD', symbol: 'C$', name: 'Canadian Dollar' },
  { code: 'AUD', symbol: 'A$', name: 'Australian Dollar' },
  { code: 'JPY', symbol: '¥', name: 'Japanese Yen' },
  { code: 'CNY', symbol: '¥', name: 'Chinese Yuan' },
] as const;
