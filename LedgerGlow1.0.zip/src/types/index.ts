export type TransactionType = 'income' | 'expense';

export type RecurringType = 'one-time' | 'weekly' | 'monthly' | 'yearly';

export interface Transaction {
  id: string;
  type: TransactionType;
  amount: number;
  category: string;
  note?: string;
  recurring: RecurringType;
  date: string;
  accountId: string;
  recurringDate?: string; // For recurring transactions: the date when the recurring payment occurs (e.g., "15" for 15th of month)
}

export interface Category {
  id: string;
  name: string;
  emoji: string;
  color: string;
}

export interface Account {
  id: string;
  name: string;
  emoji: string;
  createdAt: string;
}

export type Currency = 'USD' | 'EUR' | 'GBP' | 'CAD' | 'AUD' | 'JPY' | 'CNY';
