import { useFinanceStore } from '@/stores/financeStore';
import { formatCurrency, formatDate, convertToMonthly } from '@/lib/utils';
import { EXPENSE_CATEGORIES, INCOME_CATEGORIES } from '@/constants/categories';
import { ArrowLeft, Trash2, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

interface AllTransactionsProps {
  onBack: () => void;
}

export function AllTransactions({ onBack }: AllTransactionsProps) {
  const { transactions, currency, deleteTransaction, currentAccountId, accounts } = useFinanceStore();
  const { toast } = useToast();
  
  const accountTransactions = transactions.filter(t => t.accountId === currentAccountId);
  const currentAccount = accounts.find(a => a.id === currentAccountId);
  
  const handleExport = () => {
    if (accountTransactions.length === 0) {
      toast({
        title: 'No transactions',
        description: 'Add some transactions before exporting',
        variant: 'destructive',
      });
      return;
    }
    
    // Create CSV content
    const headers = ['Date', 'Type', 'Category', 'Amount', 'Recurring', 'Note'];
    const rows = accountTransactions.map((transaction) => {
      const categories = transaction.type === 'income' ? INCOME_CATEGORIES : EXPENSE_CATEGORIES;
      const category = categories.find((c) => c.id === transaction.category);
      
      return [
        new Date(transaction.date).toLocaleDateString(),
        transaction.type,
        category?.name || transaction.category,
        transaction.amount.toFixed(2),
        transaction.recurring,
        transaction.note || '',
      ];
    });
    
    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(',')),
    ].join('\n');
    
    // Create and download file
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `ledgerglow-transactions-${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: 'Export successful',
      description: `Exported ${accountTransactions.length} transactions`,
    });
  };
  
  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-2xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={onBack}
              className="rounded-full"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-3xl font-bold tracking-tight text-foreground">All Transactions</h1>
              <p className="text-sm text-muted-foreground mt-1">
                {currentAccount?.emoji} {currentAccount?.name} • {accountTransactions.length} transactions
              </p>
            </div>
          </div>
          
          <Button
            onClick={handleExport}
            variant="outline"
            className="rounded-xl"
            disabled={accountTransactions.length === 0}
          >
            <Download className="w-4 h-4 mr-2" />
            Export CSV
          </Button>
        </div>
        
        {/* Transactions List */}
        {accountTransactions.length === 0 ? (
          <div className="bg-card rounded-3xl p-16 shadow-sm border border-border flex items-center justify-center animate-fade-in">
            <div className="text-center">
              <div className="text-6xl mb-3">📝</div>
              <p className="text-muted-foreground text-sm">No transactions yet</p>
              <p className="text-muted-foreground text-xs mt-1">Start tracking your money</p>
            </div>
          </div>
        ) : (
          <div className="bg-card rounded-3xl p-6 shadow-sm border border-border animate-fade-in">
            <div className="space-y-3">
              {accountTransactions.map((transaction) => {
                const categories = transaction.type === 'income' ? INCOME_CATEGORIES : EXPENSE_CATEGORIES;
                const category = categories.find((c) => c.id === transaction.category);
                
                return (
                  <div
                    key={transaction.id}
                    className="flex items-center justify-between p-3 rounded-xl hover:bg-accent/50 transition-colors group"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-accent flex items-center justify-center text-xl">
                        {category?.emoji || '💰'}
                      </div>
                      <div>
                        <p className="font-medium text-sm text-foreground">
                          {category?.name || transaction.category}
                        </p>
                        <div className="flex items-center gap-2">
                          <p className="text-xs text-muted-foreground">
                            {formatDate(transaction.date)}
                          </p>
                          {transaction.recurring !== 'one-time' && (
                            <span className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full">
                              {transaction.recurring}
                            </span>
                          )}
                        </div>
                        {transaction.note && (
                          <p className="text-xs text-muted-foreground mt-0.5">{transaction.note}</p>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <div className="text-right">
                        <p
                          className={`font-semibold text-sm ${
                            transaction.type === 'income' ? 'text-income' : 'text-expense'
                          }`}
                        >
                          {transaction.type === 'income' ? '+' : '-'}
                          {formatCurrency(transaction.amount, currency)}
                        </p>
                        {transaction.recurring !== 'one-time' && transaction.recurring !== 'monthly' && (
                          <p className="text-xs text-muted-foreground">
                            {formatCurrency(convertToMonthly(transaction.amount, transaction.recurring), currency)}/mo
                          </p>
                        )}
                      </div>
                      
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={async () => {
                          try {
                            await deleteTransaction(transaction.id);
                          } catch (error: any) {
                            toast({
                              title: 'Error',
                              description: error.message || 'Failed to delete transaction',
                              variant: 'destructive',
                            });
                          }
                        }}
                        className="opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8"
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
