import { useState } from 'react';
import { useFinanceStore } from '@/stores/financeStore';
import { CURRENCIES } from '@/constants/categories';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { ArrowLeft, Trash2, LogOut } from 'lucide-react';
import { Currency } from '@/types';
import { useToast } from '@/hooks/use-toast';
import { AddAccountDialog } from '@/components/features/AddAccountDialog';

interface SettingsProps {
  onBack: () => void;
  onLogout: () => void;
}

export function Settings({ onBack, onLogout }: SettingsProps) {
  const { currency, setCurrency, accounts, deleteAccount } = useFinanceStore();
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  
  const handleCurrencyChange = async (newCurrency: string) => {
    try {
      await setCurrency(newCurrency as Currency);
      toast({
        title: 'Currency updated',
        description: `Changed to ${CURRENCIES.find((c) => c.code === newCurrency)?.name}`,
      });
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    }
  };
  
  const handleDeleteAccount = async (id: string, name: string) => {
    if (accounts.length <= 1) {
      toast({
        title: 'Cannot delete',
        description: 'You must have at least one account',
        variant: 'destructive',
      });
      return;
    }
    
    if (confirm(`Delete "${name}"? All transactions in this account will be removed.`)) {
      try {
        await deleteAccount(id);
        toast({
          title: 'Account deleted',
          description: `${name} has been removed`,
        });
      } catch (error: any) {
        toast({
          title: 'Error',
          description: error.message,
          variant: 'destructive',
        });
      }
    }
  };
  
  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-2xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="ghost"
            size="icon"
            onClick={onBack}
            className="rounded-full"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-foreground">Settings</h1>
            <p className="text-sm text-muted-foreground mt-1">Customize your preferences</p>
          </div>
        </div>
        
        {/* Accounts Card */}
        <div className="bg-card rounded-3xl p-6 shadow-sm border border-border animate-fade-in mb-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-base font-semibold">Accounts</h2>
              <p className="text-xs text-muted-foreground mt-1">Manage your accounts</p>
            </div>
            <Button
              onClick={() => setDialogOpen(true)}
              variant="outline"
              className="rounded-xl"
              size="sm"
            >
              Add Account
            </Button>
          </div>
          <div className="space-y-2">
            {accounts.map((account) => (
              <div
                key={account.id}
                className="flex items-center justify-between p-4 rounded-xl bg-secondary/50 hover:bg-secondary transition-colors"
              >
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{account.emoji}</span>
                  <span className="font-medium">{account.name}</span>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleDeleteAccount(account.id, account.name)}
                  className="rounded-xl text-destructive hover:text-destructive hover:bg-destructive/10"
                  disabled={accounts.length <= 1}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>
        </div>
        
        {/* Currency Card */}
        <div className="bg-card rounded-3xl p-6 shadow-sm border border-border animate-fade-in">
          <div className="space-y-6">
            {/* Currency Setting */}
            <div className="space-y-3">
              <Label htmlFor="currency" className="text-base font-semibold">
                Currency
              </Label>
              <Select value={currency} onValueChange={handleCurrencyChange}>
                <SelectTrigger id="currency" className="h-12 rounded-xl">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {CURRENCIES.map((curr) => (
                    <SelectItem key={curr.code} value={curr.code}>
                      <span className="flex items-center gap-2">
                        <span className="font-semibold">{curr.symbol}</span>
                        <span>{curr.name} ({curr.code})</span>
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                Choose your preferred currency for displaying amounts
              </p>
            </div>
            

          </div>
        </div>
        
        {/* Logout Button */}
        <div className="mt-6">
          <Button
            onClick={onLogout}
            variant="outline"
            className="w-full h-12 rounded-xl text-destructive border-destructive/50 hover:bg-destructive/10"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Sign Out
          </Button>
        </div>
        
        {/* App Info */}
        <div className="mt-8 space-y-3">
          <p className="text-xs text-muted-foreground text-center">
            LedgerGlow v1.0.0
          </p>
          <p className="text-xs text-muted-foreground text-center">
            Made with ❤️ for simple money tracking
          </p>
        </div>
      </div>
      
      <AddAccountDialog open={dialogOpen} onOpenChange={setDialogOpen} />
    </div>
  );
}
