import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuthStore, mapSupabaseUser } from '@/stores/authStore';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, AlertTriangle } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

export function Auth() {
  // Check for password reset token FIRST (before any state initialization)
  const checkForRecoveryToken = () => {
    const hashParams = new URLSearchParams(window.location.hash.substring(1));
    return hashParams.get('type') === 'recovery';
  };
  
  const [isLogin, setIsLogin] = useState(!checkForRecoveryToken());
  const [isResetPassword, setIsResetPassword] = useState(checkForRecoveryToken());
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [username, setUsername] = useState('');
  const [loading, setLoading] = useState(false);
  const [showGuestWarning, setShowGuestWarning] = useState(false);
  const { login, loginAsGuest } = useAuthStore();
  const { toast } = useToast();

  // Monitor URL hash changes for recovery token
  useEffect(() => {
    const handleHashChange = () => {
      const hashParams = new URLSearchParams(window.location.hash.substring(1));
      const type = hashParams.get('type');
      
      if (type === 'recovery') {
        console.log('Recovery token detected in URL');
        setIsResetPassword(true);
        setIsLogin(false);
      }
    };
    
    // Check on mount
    handleHashChange();
    
    // Listen for hash changes
    window.addEventListener('hashchange', handleHashChange);
    
    return () => {
      window.removeEventListener('hashchange', handleHashChange);
    };
  }, []);

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email || !password || !username) {
      toast({
        title: 'Missing fields',
        description: 'Please fill in all fields',
        variant: 'destructive',
      });
      return;
    }

    setLoading(true);

    try {
      // Sign up the user
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            username,
          },
        },
      });

      if (error) throw error;

      if (data.user) {
        // Auto login after signup
        login(mapSupabaseUser(data.user));
        toast({
          title: 'Account created!',
          description: 'Welcome to LedgerGlow',
        });
      }
    } catch (error: any) {
      toast({
        title: 'Signup failed',
        description: error.message,
        variant: 'destructive',
      });
      setLoading(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email || !password) {
      toast({
        title: 'Missing fields',
        description: 'Please enter email and password',
        variant: 'destructive',
      });
      return;
    }

    setLoading(true);

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) throw error;

      if (data.user) {
        login(mapSupabaseUser(data.user));
        toast({
          title: 'Welcome back!',
          description: 'Successfully logged in',
        });
      }
    } catch (error: any) {
      toast({
        title: 'Login failed',
        description: error.message,
        variant: 'destructive',
      });
      setLoading(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!password || !confirmPassword) {
      toast({
        title: 'Missing fields',
        description: 'Please enter and confirm your new password',
        variant: 'destructive',
      });
      return;
    }

    if (password !== confirmPassword) {
      toast({
        title: 'Passwords do not match',
        description: 'Please make sure both passwords are the same',
        variant: 'destructive',
      });
      return;
    }

    if (password.length < 6) {
      toast({
        title: 'Password too short',
        description: 'Password must be at least 6 characters',
        variant: 'destructive',
      });
      return;
    }

    setLoading(true);

    try {
      console.log('Attempting to update password...');
      
      const { data, error } = await supabase.auth.updateUser({
        password: password,
      });

      if (error) {
        console.error('Password update error:', error);
        throw error;
      }

      console.log('Password updated successfully:', data);

      if (data.user) {
        // Manually trigger login and data load
        const authUser = mapSupabaseUser(data.user);
        login(authUser);
        
        // Import and call loadUserData
        const { loadUserData } = await import('@/stores/financeStore');
        await loadUserData.getState().loadUserData(data.user.id);
        
        toast({
          title: 'Password updated!',
          description: 'Welcome back with your new password.',
        });
        
        // Clear the hash
        window.location.hash = '';
        
        // Don't reload - the auth state is already set
        // The App component will detect the user and show the dashboard
      }
    } catch (error: any) {
      console.error('Reset password error:', error);
      toast({
        title: 'Update failed',
        description: error.message || 'Failed to update password. Please try again.',
        variant: 'destructive',
      });
      setLoading(false);
    }
  };



  const handleGuestLogin = () => {
    loginAsGuest();
    toast({
      title: 'Logged in as Guest',
      description: '⚠️ Your data will not be saved. Create an account to save your data.',
      variant: 'default',
    });
  };

  return (
    <>
      {/* Guest Warning Dialog */}
      <AlertDialog open={showGuestWarning} onOpenChange={setShowGuestWarning}>
        <AlertDialogContent className="glass-card border-0">
          <AlertDialogHeader>
            <div className="flex items-center gap-2 mb-2">
              <AlertTriangle className="w-6 h-6 text-yellow-500" />
              <AlertDialogTitle className="text-xl">Guest Mode Warning</AlertDialogTitle>
            </div>
            <AlertDialogDescription className="text-base space-y-3 text-left">
              <p className="font-semibold text-foreground">
                Your data will NOT be saved permanently!
              </p>
              <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
                <li>All transactions and accounts are stored locally in your browser</li>
                <li>Data will be lost if you clear your browser cache</li>
                <li>Data will NOT sync across devices</li>
                <li>You cannot recover your data if you lose it</li>
              </ul>
              <p className="text-foreground font-medium">
                To save your data permanently, create a free account.
              </p>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleGuestLogin} className="bg-yellow-600 hover:bg-yellow-700">
              Continue as Guest
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <div className="min-h-screen bg-background flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        {/* Logo and Header */}
        <div className="text-center mb-8">
          <h1 className="text-5xl font-bold tracking-tight gradient-text mb-3">
            LedgerGlow
          </h1>
          <p className="text-muted-foreground">
            {isLogin ? 'Welcome back! Sign in to continue' : 'Create your account to get started'}
          </p>
        </div>

        {/* Auth Form */}
        <div className="glass-card rounded-3xl p-8 shadow-glass border-0 animate-fade-in relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-neon-cyan/5 via-transparent to-primary/5" />
          
          {/* Back button for password reset */}
          {isResetPassword && (
            <button
              type="button"
              onClick={() => {
                setIsResetPassword(false);
                setEmail('');
                setPassword('');
                setConfirmPassword('');
                setIsLogin(true);
              }}
              className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mb-4 relative z-10"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to login
            </button>
          )}
          
          <form onSubmit={isResetPassword ? handleResetPassword : (isLogin ? handleLogin : handleSignup)} className="space-y-4 relative z-10">
            {isResetPassword ? (
              <>
                <div className="space-y-2">
                  <Label htmlFor="password">New Password</Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    className="h-12 rounded-xl"
                    minLength={6}
                  />
                  <p className="text-xs text-muted-foreground">
                    Must be at least 6 characters
                  </p>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="confirmPassword">Confirm New Password</Label>
                  <Input
                    id="confirmPassword"
                    type="password"
                    placeholder="••••••••"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    required
                    className="h-12 rounded-xl"
                    minLength={6}
                  />
                </div>
              </>
            ) : (
              <>
                {!isLogin && (
                  <div className="space-y-2">
                    <Label htmlFor="username">Username</Label>
                    <Input
                      id="username"
                      type="text"
                      placeholder="Your username"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      required={!isLogin}
                      className="h-12 rounded-xl"
                    />
                  </div>
                )}

                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="you@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="h-12 rounded-xl"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    className="h-12 rounded-xl"
                    minLength={6}
                  />
                  {!isLogin && (
                    <p className="text-xs text-muted-foreground">
                      Must be at least 6 characters
                    </p>
                  )}
                </div>
              </>
            )}

            <Button
              type="submit"
              disabled={loading}
              className="w-full h-12 rounded-xl bg-gradient-to-r from-primary to-neon-purple hover:opacity-90 transition-opacity text-white font-semibold"
            >
              {loading ? 'Please wait...' : isResetPassword ? 'Update Password' : (isLogin ? 'Sign In' : 'Create Account')}
            </Button>
          </form>

          {/* Guest Login Option */}
          {!isResetPassword && (
            <div className="mt-4 relative z-10">
              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-border" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-card px-2 text-muted-foreground">Or</span>
                </div>
              </div>
              
              <Button
                type="button"
                variant="outline"
                onClick={() => setShowGuestWarning(true)}
                className="w-full mt-4 h-12 rounded-xl border-dashed hover:border-solid"
              >
                Continue as Guest
              </Button>
            </div>
          )}

          {/* Toggle between login and signup */}
          {!isResetPassword && (
            <div className="mt-6 text-center relative z-10">
              <button
                type="button"
                onClick={() => {
                  setIsLogin(!isLogin);
                  setEmail('');
                  setPassword('');
                  setUsername('');
                }}
                className="text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                {isLogin ? (
                  <>
                    Don't have an account?{' '}
                    <span className="text-primary font-semibold">Sign up</span>
                  </>
                ) : (
                  <>
                    Already have an account?{' '}
                    <span className="text-primary font-semibold">Sign in</span>
                  </>
                )}
              </button>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="mt-8">
          <p className="text-xs text-muted-foreground text-center">
            Track your money effortlessly with LedgerGlow
          </p>
        </div>
      </div>
    </div>
    </>
  );
}
