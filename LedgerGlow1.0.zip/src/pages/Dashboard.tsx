import { useState } from 'react';
import { BalanceCard } from '@/components/features/BalanceCard';
import { TransactionList } from '@/components/features/TransactionList';
import { QuickActionButton } from '@/components/features/QuickActionButton';
import { AddTransactionDialog } from '@/components/features/AddTransactionDialog';
import { AccountSelector } from '@/components/features/AccountSelector';
import { Button } from '@/components/ui/button';
import { Settings } from 'lucide-react';
import { TransactionType } from '@/types';
import { useAuthStore } from '@/stores/authStore';
import { useFinanceStore } from '@/stores/financeStore';

interface DashboardProps {
  onOpenSettings: () => void;
  onViewAllTransactions: () => void;
}

export function Dashboard({ onOpenSettings, onViewAllTransactions }: DashboardProps) {
  const { user } = useAuthStore();
  const { loading, initialized, accounts } = useFinanceStore();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string | undefined>();
  const [transactionType, setTransactionType] = useState<TransactionType>('expense');
  
  console.log('Dashboard render:', { loading, initialized, accountsCount: accounts.length });
  
  const handleCategoryClick = (categoryId: string, type: TransactionType) => {
    setSelectedCategory(categoryId);
    setTransactionType(type);
    setDialogOpen(true);
  };
  
  const handleViewAll = () => {
    console.log('Dashboard: handleViewAll called, calling onViewAllTransactions');
    onViewAllTransactions();
  };
  
  // Show loading state while data is being loaded (but only if actually loading, not just uninitialized)
  if (loading && !initialized) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block h-12 w-12 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent mb-4"></div>
          <p className="text-muted-foreground">Loading your financial data...</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-background pb-32">
      <div className="max-w-2xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold tracking-tight gradient-text">LedgerGlow</h1>
            <p className="text-sm text-muted-foreground mt-2">
              Welcome back, {user?.username || 'User'}
            </p>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onOpenSettings}
            className="rounded-full glass hover:bg-accent/50 transition-all"
          >
            <Settings className="w-5 h-5" />
          </Button>
        </div>
        
        {/* Account Selector */}
        <div className="mb-6">
          <AccountSelector />
        </div>
        
        {/* Balance Card with floating shortcuts */}
        <div className="mb-6">
          <BalanceCard onCategoryClick={handleCategoryClick} />
        </div>
        
        {/* Transaction List */}
        <div>
          <TransactionList onViewMore={handleViewAll} />
        </div>
      </div>
      
      {/* Quick Action Button */}
      <QuickActionButton />
      
      {/* Category Quick Add Dialog */}
      <AddTransactionDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        type={transactionType}
        preselectedCategory={selectedCategory}
      />
    </div>
  );
}
