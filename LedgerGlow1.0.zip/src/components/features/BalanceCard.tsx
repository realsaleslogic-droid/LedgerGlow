import { useFinanceStore } from '@/stores/financeStore';
import { formatCurrency, convertToMonthly } from '@/lib/utils';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';
import { EXPENSE_CATEGORIES, INCOME_CATEGORIES } from '@/constants/categories';
import { Button } from '@/components/ui/button';
import { TransactionType } from '@/types';
import { Calendar, CalendarDays } from 'lucide-react';

interface BalanceCardProps {
  onCategoryClick?: (categoryId: string, type: TransactionType) => void;
}

export function BalanceCard({ onCategoryClick }: BalanceCardProps) {
  const { getMonthlyIncome, getMonthlyExpense, getYearlyIncome, getYearlyExpense, currency, viewMode, setViewMode } = useFinanceStore();
  
  const income = viewMode === 'monthly' ? getMonthlyIncome() : getYearlyIncome();
  const expense = viewMode === 'monthly' ? getMonthlyExpense() : getYearlyExpense();
  const total = income + expense;
  
  // Show placeholder data when no transactions
  const data = total === 0 ? [
    { name: 'Income', value: 1, color: 'hsl(var(--income))' },
    { name: 'Expenses', value: 1, color: 'hsl(var(--expense))' },
  ] : [
    { name: 'Income', value: income, color: 'hsl(var(--income))' },
    { name: 'Expenses', value: expense, color: 'hsl(var(--expense))' },
  ];
  
  // Quick shortcuts: mix of most common income and expense categories
  const quickCategories = [
    // Income (3 categories)
    { ...INCOME_CATEGORIES.find(c => c.id === 'salary')!, type: 'income' as TransactionType },
    { ...INCOME_CATEGORIES.find(c => c.id === 'other-income')!, type: 'income' as TransactionType },
    { ...INCOME_CATEGORIES.find(c => c.id === 'freelance')!, type: 'income' as TransactionType },
    // Expenses (9 categories)
    { ...EXPENSE_CATEGORIES.find(c => c.id === 'rent')!, type: 'expense' as TransactionType },
    { ...EXPENSE_CATEGORIES.find(c => c.id === 'food')!, type: 'expense' as TransactionType },
    { ...EXPENSE_CATEGORIES.find(c => c.id === 'transportation')!, type: 'expense' as TransactionType },
    { ...EXPENSE_CATEGORIES.find(c => c.id === 'utilities')!, type: 'expense' as TransactionType },
    { ...EXPENSE_CATEGORIES.find(c => c.id === 'subscriptions')!, type: 'expense' as TransactionType },
    { ...EXPENSE_CATEGORIES.find(c => c.id === 'shopping')!, type: 'expense' as TransactionType },
    { ...EXPENSE_CATEGORIES.find(c => c.id === 'health')!, type: 'expense' as TransactionType },
    { ...EXPENSE_CATEGORIES.find(c => c.id === 'entertainment')!, type: 'expense' as TransactionType },
    { ...EXPENSE_CATEGORIES.find(c => c.id === 'other-expense')!, type: 'expense' as TransactionType },
  ];
  
  const incomePercentage = total === 0 ? '50.0' : ((income / total) * 100).toFixed(1);
  const expensePercentage = total === 0 ? '50.0' : ((expense / total) * 100).toFixed(1);
  const isEmptyState = total === 0;
  
  return (
    <div className="glass-card rounded-3xl p-10 shadow-glass border-0 animate-fade-in relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-neon-cyan/10" />
      
      {/* Header with View Mode Toggle */}
      <div className="flex items-center justify-between mb-4 relative z-10">
        <h3 className="text-sm font-semibold text-foreground px-1">
          {viewMode === 'monthly' ? 'Monthly' : 'Yearly'} Income vs Expenses
        </h3>
        <div className="flex gap-1 bg-secondary/50 rounded-xl p-1">
          <Button
            variant={viewMode === 'monthly' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setViewMode('monthly')}
            className="h-7 px-3 rounded-lg text-xs"
          >
            <Calendar className="w-3 h-3 mr-1" />
            Monthly
          </Button>
          <Button
            variant={viewMode === 'yearly' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setViewMode('yearly')}
            className="h-7 px-3 rounded-lg text-xs"
          >
            <CalendarDays className="w-3 h-3 mr-1" />
            Yearly
          </Button>
        </div>
      </div>
      
      {/* Square container to ensure perfect circle */}
      <div className="relative z-10 flex items-center justify-center">
        <div className="relative w-full max-w-[480px] aspect-square mx-auto">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                innerRadius={70}
                outerRadius={110}
                paddingAngle={2}
                dataKey="value"
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
          
          {/* Center income/expenses or empty state */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            {isEmptyState ? (
              <div className="text-center">
                <p className="text-4xl mb-2 animate-float">📊</p>
                <p className="text-foreground/80 text-xs">No transactions yet</p>
              </div>
            ) : (
              <div className="text-center space-y-1.5">
                {/* Income */}
                <div>
                  <div className="flex items-center justify-center gap-1 mb-0.5">
                    <div className="w-1.5 h-1.5 rounded-full bg-income shadow-neon-cyan" />
                    <p className="text-[8px] text-muted-foreground">
                      {viewMode === 'monthly' ? 'Monthly' : 'Yearly'} Income
                    </p>
                  </div>
                  <p className="text-xs font-bold text-income drop-shadow-[0_0_8px_rgba(34,211,238,0.5)]">
                    {formatCurrency(income, currency)}
                  </p>
                  <p className="text-[8px] text-muted-foreground mt-0.5">{incomePercentage}%</p>
                </div>
                
                {/* Divider */}
                <div className="w-10 h-px bg-border mx-auto" />
                
                {/* Expenses */}
                <div>
                  <div className="flex items-center justify-center gap-1 mb-0.5">
                    <div className="w-1.5 h-1.5 rounded-full bg-expense shadow-neon-pink" />
                    <p className="text-[8px] text-muted-foreground">
                      {viewMode === 'monthly' ? 'Monthly' : 'Yearly'} Expenses
                    </p>
                  </div>
                  <p className="text-xs font-bold text-expense drop-shadow-[0_0_8px_rgba(236,72,153,0.5)]">
                    {formatCurrency(expense, currency)}
                  </p>
                  <p className="text-[8px] text-muted-foreground mt-0.5">{expensePercentage}%</p>
                </div>
              </div>
            )}
          </div>
          
          {/* Floating category shortcuts in circular formation */}
          {onCategoryClick && (
            <div className="absolute inset-0 pointer-events-none">
              {quickCategories.map((category, index) => {
                // Distribute evenly in a circle, starting from top (-90 degrees)
                const angle = (index * 360) / quickCategories.length - 90;
                const radius = 52; // Distance from center as percentage of container half-width/height (creates consistent spacing from pie chart edge)
                const radians = (angle * Math.PI) / 180;
                const x = Math.cos(radians) * radius;
                const y = Math.sin(radians) * radius;
                
                return (
                  <button
                    key={category.id}
                    onClick={() => onCategoryClick(category.id, category.type)}
                    className="absolute flex flex-col items-center justify-center gap-0.5 w-10 h-10 text-lg hover:scale-125 transition-transform duration-300 cursor-pointer pointer-events-auto group"
                    style={{
                      left: `calc(50% + ${x}%)`,
                      top: `calc(50% + ${y}%)`,
                      transform: 'translate(-50%, -50%)',
                    }}
                    title={category.name}
                  >
                    <span className="drop-shadow-lg block">{category.emoji}</span>
                    <span className="text-[9px] font-medium text-foreground/70 whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity absolute -bottom-4">
                      {category.name}
                    </span>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
