import { useState } from 'react';
import { Plus, Minus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { AddTransactionDialog } from './AddTransactionDialog';
import { TransactionType } from '@/types';

export function QuickActionButton() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [transactionType, setTransactionType] = useState<TransactionType>('expense');
  
  const handleAction = (type: TransactionType) => {
    setTransactionType(type);
    setDialogOpen(true);
  };
  
  return (
    <>
      <div className="fixed bottom-8 left-1/2 -translate-x-1/2 z-50">
        <div className="flex gap-4 animate-fade-in">
          <Button
            onClick={() => handleAction('income')}
            className="h-20 w-20 rounded-full shadow-neon-cyan glass border-2 border-income/50 bg-income/20 hover:bg-income/30 text-income hover:scale-110 transition-all backdrop-blur-xl relative overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-income/10 to-neon-cyan/10 animate-pulse" />
            <Plus className="w-8 h-8 relative z-10 drop-shadow-[0_0_8px_rgba(34,211,238,0.5)]" />
          </Button>
          <Button
            onClick={() => handleAction('expense')}
            className="h-20 w-20 rounded-full shadow-neon-pink glass border-2 border-expense/50 bg-expense/20 hover:bg-expense/30 text-expense hover:scale-110 transition-all backdrop-blur-xl relative overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-expense/10 to-neon-pink/10 animate-pulse" />
            <Minus className="w-8 h-8 relative z-10 drop-shadow-[0_0_8px_rgba(236,72,153,0.5)]" />
          </Button>
        </div>
      </div>
      
      <AddTransactionDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        type={transactionType}
      />
    </>
  );
}
