import { useFinanceStore } from '@/stores/financeStore';
import { EXPENSE_CATEGORIES } from '@/constants/categories';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend } from 'recharts';

export function ExpenseChart() {
  const { getExpensesByCategory } = useFinanceStore();
  const expenseData = getExpensesByCategory();
  
  if (expenseData.length === 0) {
    return (
      <div className="bg-card rounded-3xl p-8 shadow-sm border border-border flex items-center justify-center min-h-[320px] animate-fade-in">
        <div className="text-center">
          <div className="text-6xl mb-3">💸</div>
          <p className="text-muted-foreground text-sm">No expenses yet</p>
          <p className="text-muted-foreground text-xs mt-1">Start tracking your spending</p>
        </div>
      </div>
    );
  }
  
  const chartData = expenseData.map((item) => {
    const category = EXPENSE_CATEGORIES.find((c) => c.id === item.category);
    return {
      name: category?.name || item.category,
      value: item.amount,
      color: category?.color || 'hsl(200, 20%, 50%)',
      emoji: category?.emoji || '📦',
    };
  });
  
  return (
    <div className="bg-card rounded-3xl p-6 shadow-sm border border-border animate-fade-in">
      <h3 className="text-sm font-semibold text-foreground mb-4 px-2">Spending Breakdown</h3>
      
      <ResponsiveContainer width="100%" height={280}>
        <PieChart>
          <Pie
            data={chartData}
            cx="50%"
            cy="50%"
            innerRadius={60}
            outerRadius={90}
            paddingAngle={4}
            dataKey="value"
          >
            {chartData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color} />
            ))}
          </Pie>
          <Legend
            verticalAlign="bottom"
            height={36}
            iconType="circle"
            formatter={(value, entry: any) => (
              <span className="text-xs text-foreground">
                {entry.payload.emoji} {value}
              </span>
            )}
          />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}
