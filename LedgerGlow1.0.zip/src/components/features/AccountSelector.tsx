import { useFinanceStore } from '@/stores/financeStore';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';
import { useState } from 'react';
import { AddAccountDialog } from './AddAccountDialog';

export function AccountSelector() {
  const { accounts, currentAccountId, setCurrentAccount } = useFinanceStore();
  const [dialogOpen, setDialogOpen] = useState(false);
  
  const currentAccount = accounts.find((a) => a.id === currentAccountId);
  
  console.log('AccountSelector render:', { accounts, currentAccountId, currentAccount });
  
  // If no accounts, show error state
  if (!accounts || accounts.length === 0) {
    return (
      <div className="flex items-center gap-2 animate-fade-in">
        <div className="glass-card rounded-xl p-3 flex-1">
          <p className="text-sm text-muted-foreground">No accounts found. Creating default account...</p>
        </div>
        <Button
          variant="outline"
          size="icon"
          onClick={() => setDialogOpen(true)}
          className="h-11 w-11 rounded-xl border-2"
        >
          <Plus className="w-5 h-5" />
        </Button>
        <AddAccountDialog open={dialogOpen} onOpenChange={setDialogOpen} />
      </div>
    );
  }
  
  return (
    <>
      <div className="flex items-center gap-2 animate-fade-in">
        <Select value={currentAccountId} onValueChange={setCurrentAccount}>
          <SelectTrigger className="h-11 rounded-xl border-2 min-w-[160px]">
            <SelectValue>
              <span className="flex items-center gap-2">
                <span>{currentAccount?.emoji}</span>
                <span className="font-medium">{currentAccount?.name}</span>
              </span>
            </SelectValue>
          </SelectTrigger>
          <SelectContent>
            {accounts.map((account) => (
              <SelectItem key={account.id} value={account.id}>
                <span className="flex items-center gap-2">
                  <span>{account.emoji}</span>
                  <span>{account.name}</span>
                </span>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        
        <Button
          variant="outline"
          size="icon"
          onClick={() => setDialogOpen(true)}
          className="h-11 w-11 rounded-xl border-2"
        >
          <Plus className="w-5 h-5" />
        </Button>
      </div>
      
      <AddAccountDialog open={dialogOpen} onOpenChange={setDialogOpen} />
    </>
  );
}
