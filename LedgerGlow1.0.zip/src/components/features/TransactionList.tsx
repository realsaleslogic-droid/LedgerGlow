import { useFinanceStore } from '@/stores/financeStore';
import { formatCurrency, formatDate, convertToMonthly } from '@/lib/utils';
import { EXPENSE_CATEGORIES, INCOME_CATEGORIES } from '@/constants/categories';
import { Trash2, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface TransactionListProps {
  onViewMore?: () => void;
}

export function TransactionList({ onViewMore }: TransactionListProps) {
  const { transactions, currency, deleteTransaction, currentAccountId } = useFinanceStore();
  
  const accountTransactions = transactions.filter(t => t.accountId === currentAccountId);
  
  if (accountTransactions.length === 0) {
    return (
      <div className="glass-card rounded-3xl p-8 shadow-glass border-0 flex items-center justify-center min-h-[200px] animate-fade-in relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-neon-cyan/5 via-transparent to-primary/5" />
        <div className="text-center relative z-10">
          <div className="text-6xl mb-3 animate-float">📝</div>
          <p className="text-foreground/80 text-sm">No transactions yet</p>
          <p className="text-muted-foreground text-xs mt-1">Tap + or - to get started</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="glass-card rounded-3xl p-6 shadow-glass border-0 animate-fade-in relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-neon-pink/5" />
      <h3 className="text-sm font-semibold text-foreground mb-4 relative z-10">Recent Transactions</h3>
      
      <div className="space-y-3 relative z-10">
        {accountTransactions.slice(0, 3).map((transaction) => {
          const categories = transaction.type === 'income' ? INCOME_CATEGORIES : EXPENSE_CATEGORIES;
          const category = categories.find((c) => c.id === transaction.category);
          
          return (
            <div
              key={transaction.id}
              className="flex items-center justify-between p-3 rounded-xl glass hover:shadow-neon-purple/30 transition-all group"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-accent flex items-center justify-center text-xl">
                  {category?.emoji || '💰'}
                </div>
                <div>
                  <p className="font-medium text-sm text-foreground">
                    {category?.name || transaction.category}
                  </p>
                  <div className="flex items-center gap-2">
                    <p className="text-xs text-muted-foreground">
                      {formatDate(transaction.date)}
                    </p>
                    {transaction.recurring !== 'one-time' && (
                      <span className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full">
                        {transaction.recurring}
                      </span>
                    )}
                  </div>
                  {transaction.note && (
                    <p className="text-xs text-muted-foreground mt-0.5">{transaction.note}</p>
                  )}
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                <div className="text-right">
                  <p
                    className={`font-semibold text-sm ${
                      transaction.type === 'income' ? 'text-income' : 'text-expense'
                    }`}
                  >
                    {transaction.type === 'income' ? '+' : '-'}
                    {formatCurrency(transaction.amount, currency)}
                  </p>
                  {transaction.recurring !== 'one-time' && transaction.recurring !== 'monthly' && (
                    <p className="text-xs text-muted-foreground">
                      {formatCurrency(convertToMonthly(transaction.amount, transaction.recurring), currency)}/mo
                    </p>
                  )}
                </div>
                
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={async () => {
                    try {
                      await deleteTransaction(transaction.id);
                    } catch (error: any) {
                      console.error('Error deleting transaction:', error);
                      alert('Failed to delete transaction: ' + error.message);
                    }
                  }}
                  className="opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8"
                >
                  <Trash2 className="w-4 h-4 text-destructive" />
                </Button>
              </div>
            </div>
          );
        })}
      </div>
      
      {/* View All Button */}
      {accountTransactions.length > 3 && onViewMore && (
        <Button
          onClick={() => {
            console.log('TransactionList: Button clicked, calling onViewMore');
            onViewMore();
          }}
          variant="ghost"
          className="w-full mt-4 text-sm font-medium text-primary hover:text-primary/80 hover:bg-primary/5 rounded-xl transition-all group relative z-20"
        >
          View My Transactions
          <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
        </Button>
      )}
    </div>
  );
}
