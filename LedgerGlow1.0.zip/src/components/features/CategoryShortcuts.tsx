import { EXPENSE_CATEGORIES, INCOME_CATEGORIES } from '@/constants/categories';
import { Button } from '@/components/ui/button';
import { TransactionType } from '@/types';

interface CategoryShortcutsProps {
  onCategoryClick: (categoryId: string, type: TransactionType) => void;
}

export function CategoryShortcuts({ onCategoryClick }: CategoryShortcutsProps) {
  // Quick shortcuts: mix of most common income and expense categories
  const quickCategories = [
    // Income
    { ...INCOME_CATEGORIES.find(c => c.id === 'salary')!, type: 'income' as TransactionType },
    { ...INCOME_CATEGORIES.find(c => c.id === 'bonus')!, type: 'income' as TransactionType },
    { ...INCOME_CATEGORIES.find(c => c.id === 'freelance')!, type: 'income' as TransactionType },
    // Expenses
    { ...EXPENSE_CATEGORIES.find(c => c.id === 'rent')!, type: 'expense' as TransactionType },
    { ...EXPENSE_CATEGORIES.find(c => c.id === 'food')!, type: 'expense' as TransactionType },
    { ...EXPENSE_CATEGORIES.find(c => c.id === 'transportation')!, type: 'expense' as TransactionType },
    { ...EXPENSE_CATEGORIES.find(c => c.id === 'utilities')!, type: 'expense' as TransactionType },
    { ...EXPENSE_CATEGORIES.find(c => c.id === 'subscriptions')!, type: 'expense' as TransactionType },
  ];
  
  return (
    <div className="glass-card rounded-3xl p-6 shadow-glass border-0 animate-fade-in relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-neon-purple/5 via-transparent to-neon-pink/5" />
      <h3 className="text-sm font-semibold text-foreground mb-4 relative z-10">Quick Add</h3>
      <div className="grid grid-cols-4 gap-3 relative z-10">
        {quickCategories.map((category) => (
          <Button
            key={category.id}
            variant="outline"
            onClick={() => onCategoryClick(category.id, category.type)}
            className="h-auto flex flex-col items-center gap-2 p-4 rounded-2xl border-2 glass hover:border-primary hover:shadow-neon-purple hover:scale-105 transition-all"
          >
            <span className="text-3xl">{category.emoji}</span>
            <span className="text-xs font-medium text-foreground">{category.name}</span>
          </Button>
        ))}
      </div>
    </div>
  );
}
