import { useState } from 'react';
import { useFinanceStore } from '@/stores/financeStore';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';

const ACCOUNT_EMOJIS = ['💳', '💰', '🏦', '💵', '🪙', '💎', '🎯', '📊'];

interface AddAccountDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function AddAccountDialog({ open, onOpenChange }: AddAccountDialogProps) {
  const [name, setName] = useState('');
  const [selectedEmoji, setSelectedEmoji] = useState('💳');
  
  const { addAccount } = useFinanceStore();
  const { toast } = useToast();
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name.trim()) {
      toast({
        title: 'Enter account name',
        description: 'Please provide a name for your account',
        variant: 'destructive',
      });
      return;
    }
    
    try {
      await addAccount({
        name: name.trim(),
        emoji: selectedEmoji,
      });
      
      toast({
        title: 'Account created',
        description: `${selectedEmoji} ${name} has been added`,
      });
      
      // Reset form
      setName('');
      setSelectedEmoji('💳');
      onOpenChange(false);
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to create account',
        variant: 'destructive',
      });
    }
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl">Add New Account</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-5 pt-2">
          <div className="space-y-2">
            <Label htmlFor="account-name">Account Name</Label>
            <Input
              id="account-name"
              placeholder="e.g., Checking, Savings, Cash..."
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="h-12 rounded-xl"
              autoFocus
            />
          </div>
          
          <div className="space-y-2">
            <Label>Choose Icon</Label>
            <div className="grid grid-cols-8 gap-2">
              {ACCOUNT_EMOJIS.map((emoji) => (
                <button
                  key={emoji}
                  type="button"
                  onClick={() => setSelectedEmoji(emoji)}
                  className={`text-3xl p-2 rounded-xl transition-all ${
                    selectedEmoji === emoji
                      ? 'bg-primary/20 ring-2 ring-primary'
                      : 'bg-secondary hover:bg-accent'
                  }`}
                >
                  {emoji}
                </button>
              ))}
            </div>
          </div>
          
          <Button type="submit" className="w-full h-12 rounded-xl text-base font-semibold">
            Create Account
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
