import { create } from 'zustand';
import { Transaction, Currency, Account } from '@/types';
import { convertToMonthly } from '@/lib/utils';
import { supabase } from '@/lib/supabase';

type ViewMode = 'monthly' | 'yearly';

interface FinanceStore {
  transactions: Transaction[];
  accounts: Account[];
  currentAccountId: string;
  currency: Currency;
  viewMode: ViewMode;
  loading: boolean;
  initialized: boolean;
  
  // Data operations
  loadUserData: (userId: string) => Promise<void>;
  clearData: () => void;
  
  addTransaction: (transaction: Omit<Transaction, 'id' | 'date' | 'accountId'>) => Promise<void>;
  deleteTransaction: (id: string) => Promise<void>;
  addAccount: (account: Omit<Account, 'id' | 'createdAt'>) => Promise<void>;
  deleteAccount: (id: string) => Promise<void>;
  setCurrentAccount: (id: string) => void;
  setCurrency: (currency: Currency) => Promise<void>;
  setViewMode: (mode: ViewMode) => Promise<void>;
  
  // Calculations
  getTotalIncome: () => number;
  getTotalExpense: () => number;
  getBalance: () => number;
  getMonthlyIncome: () => number;
  getMonthlyExpense: () => number;
  getMonthlyBalance: () => number;
  getYearlyIncome: () => number;
  getYearlyExpense: () => number;
  getYearlyBalance: () => number;
  getExpensesByCategory: () => { category: string; amount: number; percentage: number }[];
}

// Helper function to check if a recurring transaction is active for the current period
function isRecurringActive(transaction: Transaction, now: Date): boolean {
  if (!transaction.recurringDate) return true;
  
  const currentDay = now.getDate();
  const currentDayOfWeek = now.getDay();
  const currentMonth = now.getMonth();
  const currentYear = now.getFullYear();
  
  switch (transaction.recurring) {
    case 'monthly':
      const monthlyDate = new Date(transaction.recurringDate);
      const recurringDay = monthlyDate.getDate();
      const lastDayOfMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
      const effectiveDay = Math.min(recurringDay, lastDayOfMonth);
      return currentDay >= effectiveDay;
      
    case 'weekly':
      const weeklyDay = parseInt(transaction.recurringDate);
      return currentDayOfWeek >= weeklyDay;
      
    case 'yearly':
      const yearlyDate = new Date(transaction.recurringDate);
      const thisYearDate = new Date(currentYear, yearlyDate.getMonth(), yearlyDate.getDate());
      return now >= thisYearDate;
      
    default:
      return true;
  }
}

export const useFinanceStore = create<FinanceStore>((set, get) => ({
  transactions: [],
  accounts: [],
  currentAccountId: '',
  currency: 'USD',
  viewMode: 'monthly',
  loading: false,
  initialized: false,
  
  loadUserData: async (userId: string) => {
    set({ loading: true });
    
    // Guest mode - load from localStorage
    if (userId === 'guest') {
      try {
        const savedData = localStorage.getItem('ledgerglow_guest_data');
        if (savedData) {
          const parsed = JSON.parse(savedData);
          set({
            transactions: parsed.transactions || [],
            accounts: parsed.accounts || [{ id: 'guest-main', name: 'Main Account', emoji: '💳', createdAt: new Date().toISOString() }],
            currentAccountId: parsed.currentAccountId || 'guest-main',
            currency: parsed.currency || 'USD',
            viewMode: parsed.viewMode || 'monthly',
            loading: false,
            initialized: true,
          });
        } else {
          set({
            accounts: [{ id: 'guest-main', name: 'Main Account', emoji: '💳', createdAt: new Date().toISOString() }],
            currentAccountId: 'guest-main',
            currency: 'USD',
            viewMode: 'monthly',
            loading: false,
            initialized: true,
          });
        }
      } catch (error) {
        console.error('Error loading guest data:', error);
        set({
          accounts: [{ id: 'guest-main', name: 'Main Account', emoji: '💳', createdAt: new Date().toISOString() }],
          currentAccountId: 'guest-main',
          loading: false,
          initialized: true,
        });
      }
      return;
    }
    
    try {
      // Load user preferences
      const { data: profile } = await supabase
        .from('user_profiles')
        .select('currency, view_mode')
        .eq('id', userId)
        .single();
      
      // Load accounts
      const { data: accountsData, error: accountsError } = await supabase
        .from('accounts')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: true });
      
      if (accountsError) throw accountsError;
      
      // If no accounts exist, create a default one
      let accounts: Account[] = [];
      if (!accountsData || accountsData.length === 0) {
        const { data: newAccount, error: createError } = await supabase
          .from('accounts')
          .insert({
            user_id: userId,
            name: 'Main Account',
            emoji: '💳',
          })
          .select()
          .single();
        
        if (createError) throw createError;
        accounts = [newAccount as Account];
      } else {
        accounts = accountsData.map((a) => ({
          id: a.id,
          name: a.name,
          emoji: a.emoji,
          createdAt: a.created_at,
        }));
      }
      
      // Load transactions
      const { data: transactionsData, error: transactionsError } = await supabase
        .from('transactions')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });
      
      if (transactionsError) throw transactionsError;
      
      const transactions: Transaction[] = (transactionsData || []).map((t) => ({
        id: t.id,
        amount: parseFloat(t.amount),
        type: t.type,
        category: t.category,
        note: t.description,
        date: t.date,
        recurring: t.frequency === 'once' ? 'one-time' : (t.frequency || 'one-time'),
        recurringDate: t.recurring_date,
        accountId: t.account_id,
      }));
      
      console.log('Setting finance data:', { accounts, transactions: transactions.length });
      set({
        accounts,
        transactions,
        currentAccountId: accounts[0]?.id || '',
        currency: (profile?.currency as Currency) || 'USD',
        viewMode: (profile?.view_mode as ViewMode) || 'monthly',
        loading: false,
        initialized: true,
      });
      console.log('Finance data initialized');
    } catch (error) {
      console.error('Error loading user data:', error);
      set({ loading: false, initialized: true });
      throw error;
    }
  },
  
  clearData: () => {
    set({
      transactions: [],
      accounts: [],
      currentAccountId: '',
      currency: 'USD',
      viewMode: 'monthly',
      initialized: false,
    });
  },
  
  addTransaction: async (transaction) => {
    const state = get();
    const { data: { user } } = await supabase.auth.getUser();
    
    // Guest mode - save to localStorage
    if (!user || user.id === 'guest') {
      const newTransaction: Transaction = {
        id: `guest-${Date.now()}`,
        amount: transaction.amount,
        type: transaction.type,
        category: transaction.category,
        note: transaction.note,
        date: new Date().toISOString(),
        recurring: transaction.recurring,
        recurringDate: transaction.recurringDate,
        accountId: state.currentAccountId,
      };
      
      const newTransactions = [newTransaction, ...state.transactions];
      set({ transactions: newTransactions });
      
      // Save to localStorage
      localStorage.setItem('ledgerglow_guest_data', JSON.stringify({
        transactions: newTransactions,
        accounts: state.accounts,
        currentAccountId: state.currentAccountId,
        currency: state.currency,
        viewMode: state.viewMode,
      }));
      
      return;
    }
    
    if (!user) throw new Error('Not authenticated');
    
    const { data, error } = await supabase
      .from('transactions')
      .insert({
        user_id: user.id,
        account_id: state.currentAccountId,
        amount: transaction.amount,
        type: transaction.type,
        category: transaction.category,
        description: transaction.note || null,
        date: new Date().toISOString(),
        frequency: transaction.recurring === 'one-time' ? 'once' : transaction.recurring,
        recurring_date: transaction.recurringDate,
      })
      .select()
      .single();
    
    if (error) {
      console.error('Transaction insert error:', error);
      throw error;
    }
    
    const newTransaction: Transaction = {
      id: data.id,
      amount: parseFloat(data.amount),
      type: data.type,
      category: data.category,
      note: data.description,
      date: data.date,
      recurring: data.frequency === 'once' ? 'one-time' : (data.frequency || 'one-time'),
      recurringDate: data.recurring_date,
      accountId: data.account_id,
    };
    
    set((state) => ({
      transactions: [newTransaction, ...state.transactions],
    }));
  },
  
  deleteTransaction: async (id) => {
    const { data: { user } } = await supabase.auth.getUser();
    
    // Guest mode - update localStorage
    if (!user || user.id === 'guest') {
      const state = get();
      const newTransactions = state.transactions.filter((t) => t.id !== id);
      set({ transactions: newTransactions });
      
      localStorage.setItem('ledgerglow_guest_data', JSON.stringify({
        transactions: newTransactions,
        accounts: state.accounts,
        currentAccountId: state.currentAccountId,
        currency: state.currency,
        viewMode: state.viewMode,
      }));
      
      return;
    }
    
    const { error } = await supabase
      .from('transactions')
      .delete()
      .eq('id', id);
    
    if (error) throw error;
    
    set((state) => ({
      transactions: state.transactions.filter((t) => t.id !== id),
    }));
  },
  
  addAccount: async (account) => {
    const { data: { user } } = await supabase.auth.getUser();
    
    // Guest mode - save to localStorage
    if (!user || user.id === 'guest') {
      const state = get();
      const newAccount: Account = {
        id: `guest-account-${Date.now()}`,
        name: account.name,
        emoji: account.emoji,
        createdAt: new Date().toISOString(),
      };
      
      const newAccounts = [...state.accounts, newAccount];
      set({ accounts: newAccounts });
      
      localStorage.setItem('ledgerglow_guest_data', JSON.stringify({
        transactions: state.transactions,
        accounts: newAccounts,
        currentAccountId: state.currentAccountId,
        currency: state.currency,
        viewMode: state.viewMode,
      }));
      
      return;
    }
    
    if (!user) throw new Error('Not authenticated');
    
    const { data, error } = await supabase
      .from('accounts')
      .insert({
        user_id: user.id,
        name: account.name,
        emoji: account.emoji,
      })
      .select()
      .single();
    
    if (error) throw error;
    
    const newAccount: Account = {
      id: data.id,
      name: data.name,
      emoji: data.emoji,
      createdAt: data.created_at,
    };
    
    set((state) => ({
      accounts: [...state.accounts, newAccount],
    }));
  },
  
  deleteAccount: async (id) => {
    const state = get();
    if (state.accounts.length <= 1) {
      throw new Error('Cannot delete the last account');
    }
    
    const { data: { user } } = await supabase.auth.getUser();
    
    // Guest mode - update localStorage
    if (!user || user.id === 'guest') {
      const newAccounts = state.accounts.filter((a) => a.id !== id);
      const newTransactions = state.transactions.filter((t) => t.accountId !== id);
      
      let newCurrentAccountId = state.currentAccountId;
      if (id === state.currentAccountId) {
        const remainingAccount = newAccounts[0];
        if (remainingAccount) {
          newCurrentAccountId = remainingAccount.id;
        }
      }
      
      set({ 
        accounts: newAccounts,
        transactions: newTransactions,
        currentAccountId: newCurrentAccountId,
      });
      
      localStorage.setItem('ledgerglow_guest_data', JSON.stringify({
        transactions: newTransactions,
        accounts: newAccounts,
        currentAccountId: newCurrentAccountId,
        currency: state.currency,
        viewMode: state.viewMode,
      }));
      
      return;
    }
    
    const { error } = await supabase
      .from('accounts')
      .delete()
      .eq('id', id);
    
    if (error) throw error;
    
    // If deleting current account, switch to another one
    if (id === state.currentAccountId) {
      const remainingAccount = state.accounts.find((a) => a.id !== id);
      if (remainingAccount) {
        set({ currentAccountId: remainingAccount.id });
      }
    }
    
    set((state) => ({
      accounts: state.accounts.filter((a) => a.id !== id),
      transactions: state.transactions.filter((t) => t.accountId !== id),
    }));
  },
  
  setCurrentAccount: (id) => set({ currentAccountId: id }),
  
  setCurrency: async (currency) => {
    const { data: { user } } = await supabase.auth.getUser();
    
    // Guest mode - update localStorage
    if (!user || user.id === 'guest') {
      const state = get();
      set({ currency });
      
      localStorage.setItem('ledgerglow_guest_data', JSON.stringify({
        transactions: state.transactions,
        accounts: state.accounts,
        currentAccountId: state.currentAccountId,
        currency: currency,
        viewMode: state.viewMode,
      }));
      
      return;
    }
    
    if (!user) throw new Error('Not authenticated');
    
    const { error } = await supabase
      .from('user_profiles')
      .update({ currency })
      .eq('id', user.id);
    
    if (error) throw error;
    
    set({ currency });
  },
  
  setViewMode: async (mode) => {
    const { data: { user } } = await supabase.auth.getUser();
    
    // Update UI immediately for better UX
    set({ viewMode: mode });
    
    // Guest mode - update localStorage
    if (!user || user.id === 'guest') {
      const state = get();
      localStorage.setItem('ledgerglow_guest_data', JSON.stringify({
        transactions: state.transactions,
        accounts: state.accounts,
        currentAccountId: state.currentAccountId,
        currency: state.currency,
        viewMode: mode,
      }));
      return;
    }
    
    if (!user) {
      console.error('Not authenticated');
      return;
    }
    
    // Then sync to database
    const { error } = await supabase
      .from('user_profiles')
      .update({ view_mode: mode })
      .eq('id', user.id);
    
    if (error) {
      console.error('Error updating view mode:', error);
      // Don't throw - keep the UI updated even if DB sync fails
    }
  },
  
  getTotalIncome: () => {
    const currentAccountId = get().currentAccountId;
    return get().transactions
      .filter((t) => t.type === 'income' && t.accountId === currentAccountId)
      .reduce((sum, t) => sum + t.amount, 0);
  },
  
  getTotalExpense: () => {
    const currentAccountId = get().currentAccountId;
    return get().transactions
      .filter((t) => t.type === 'expense' && t.accountId === currentAccountId)
      .reduce((sum, t) => sum + t.amount, 0);
  },
  
  getBalance: () => {
    return get().getTotalIncome() - get().getTotalExpense();
  },
  
  getMonthlyIncome: () => {
    const currentAccountId = get().currentAccountId;
    const now = new Date();
    return get().transactions
      .filter((t) => t.type === 'income' && t.accountId === currentAccountId)
      .filter((t) => {
        if (t.recurring === 'one-time') return true;
        return isRecurringActive(t, now);
      })
      .reduce((sum, t) => sum + convertToMonthly(t.amount, t.recurring), 0);
  },
  
  getMonthlyExpense: () => {
    const currentAccountId = get().currentAccountId;
    const now = new Date();
    return get().transactions
      .filter((t) => t.type === 'expense' && t.accountId === currentAccountId)
      .filter((t) => {
        if (t.recurring === 'one-time') return true;
        return isRecurringActive(t, now);
      })
      .reduce((sum, t) => sum + convertToMonthly(t.amount, t.recurring), 0);
  },
  
  getMonthlyBalance: () => {
    return get().getMonthlyIncome() - get().getMonthlyExpense();
  },
  
  getYearlyIncome: () => {
    const currentAccountId = get().currentAccountId;
    const now = new Date();
    return get().transactions
      .filter((t) => t.type === 'income' && t.accountId === currentAccountId)
      .filter((t) => {
        if (t.recurring === 'one-time') return true;
        return isRecurringActive(t, now);
      })
      .reduce((sum, t) => {
        if (t.recurring === 'one-time') return sum + t.amount;
        return sum + convertToMonthly(t.amount, t.recurring) * 12;
      }, 0);
  },
  
  getYearlyExpense: () => {
    const currentAccountId = get().currentAccountId;
    const now = new Date();
    return get().transactions
      .filter((t) => t.type === 'expense' && t.accountId === currentAccountId)
      .filter((t) => {
        if (t.recurring === 'one-time') return true;
        return isRecurringActive(t, now);
      })
      .reduce((sum, t) => {
        if (t.recurring === 'one-time') return sum + t.amount;
        return sum + convertToMonthly(t.amount, t.recurring) * 12;
      }, 0);
  },
  
  getYearlyBalance: () => {
    return get().getYearlyIncome() - get().getYearlyExpense();
  },
  
  getExpensesByCategory: () => {
    const currentAccountId = get().currentAccountId;
    const expenses = get().transactions.filter(
      (t) => t.type === 'expense' && t.accountId === currentAccountId
    );
    const total = expenses.reduce((sum, t) => sum + t.amount, 0);
    
    const categoryMap = new Map<string, number>();
    expenses.forEach((t) => {
      const current = categoryMap.get(t.category) || 0;
      categoryMap.set(t.category, current + t.amount);
    });
    
    return Array.from(categoryMap.entries())
      .map(([category, amount]) => ({
        category,
        amount,
        percentage: total > 0 ? (amount / total) * 100 : 0,
      }))
      .sort((a, b) => b.amount - a.amount);
  },
}));
