import { create } from 'zustand';
import { supabase } from '@/lib/supabase';
import type { User } from '@supabase/supabase-js';
import { useFinanceStore } from './financeStore';

export interface AuthUser {
  id: string;
  email: string;
  username: string;
  avatar?: string;
  isGuest?: boolean;
}

interface AuthStore {
  user: AuthUser | null;
  loading: boolean;
  login: (user: AuthUser) => void;
  loginAsGuest: () => void;
  logout: () => void;
  setLoading: (loading: boolean) => void;
}

export const useAuthStore = create<AuthStore>((set) => ({
  user: null,
  loading: true,
  login: (user) => set({ user, loading: false }),
  loginAsGuest: () => set({ 
    user: {
      id: 'guest',
      email: 'guest@ledgerglow.app',
      username: 'Guest User',
      isGuest: true,
    }, 
    loading: false 
  }),
  logout: () => set({ user: null, loading: false }),
  setLoading: (loading) => set({ loading }),
}));

// Helper function to map Supabase user to AuthUser
export function mapSupabaseUser(user: User): AuthUser {
  return {
    id: user.id,
    email: user.email!,
    username: user.user_metadata?.username || user.user_metadata?.full_name || user.email!.split('@')[0],
    avatar: user.user_metadata?.avatar_url || user.user_metadata?.picture,
  };
}

// Initialize auth state
export function initializeAuth() {
  const { login, logout, setLoading } = useAuthStore.getState();
  const { loadUserData, clearData } = useFinanceStore.getState();
  let mounted = true;

  // Check existing session
  supabase.auth.getSession().then(async ({ data: { session } }) => {
    if (mounted && session?.user) {
      login(mapSupabaseUser(session.user));
      // Load user's financial data
      try {
        await loadUserData(session.user.id);
      } catch (error) {
        console.error('Error loading user data:', error);
      }
    }
    if (mounted) setLoading(false);
  });

  // Listen to auth changes
  const { data: { subscription } } = supabase.auth.onAuthStateChange(
    async (event, session) => {
      if (!mounted) return;
      
      if (event === 'SIGNED_IN' && session?.user) {
        login(mapSupabaseUser(session.user));
        // Load user's financial data
        try {
          await loadUserData(session.user.id);
        } catch (error) {
          console.error('Error loading user data:', error);
        }
        setLoading(false);
      } else if (event === 'SIGNED_OUT') {
        logout();
        clearData();
        setLoading(false);
      } else if (event === 'TOKEN_REFRESHED' && session?.user) {
        login(mapSupabaseUser(session.user));
      }
    }
  );

  return () => {
    mounted = false;
    subscription.unsubscribe();
  };
}
