import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"
import { CURRENCIES } from '@/constants/categories';
import { Currency } from '@/types';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatCurrency(amount: number, currency: Currency): string {
  const currencyInfo = CURRENCIES.find((c) => c.code === currency);
  const symbol = currencyInfo?.symbol || '$';
  
  return `${symbol}${Math.abs(amount).toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

export function formatDate(dateString: string): string {
  const date = new Date(dateString);
  const now = new Date();
  
  return date.toLocaleDateString('en-US', { 
    month: 'short', 
    day: 'numeric',
    year: date.getFullYear() !== now.getFullYear() ? 'numeric' : undefined
  });
}

// Convert transaction amount to monthly equivalent based on recurring frequency
export function convertToMonthly(amount: number, recurring: 'one-time' | 'monthly' | 'weekly' | 'yearly'): number {
  switch (recurring) {
    case 'weekly':
      return amount * 4.33; // Average weeks per month
    case 'yearly':
      return amount / 12;
    case 'monthly':
    case 'one-time':
    default:
      return amount;
  }
}
